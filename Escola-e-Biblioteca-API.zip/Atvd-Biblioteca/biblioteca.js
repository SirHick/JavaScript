const express = require('express');

const server = express();

const livros = ['Dom Casmurro', 'Escrava Isaura', 'A história de Despereaux', 'Diário de um Banana']

// Listar todos os livros
server.get('/livro', (req, res) => {

    //retorna o array inteiro
    return res.json(livros);
});

//Route Params = /curso/2
//Buscar um livro específico
server.get('/livro/:id', (req, res) => {

    const { id } = req.params;

    //retorna apenas o que foi pedido pelo id
    return res.json(livros[id]);
});

//Faz o código abaixo ser interpretado como JSON
server.use(express.json());

//Cadastrar um novo livro
server.post('/livro', (req, res) => {
    
    //Desestrutura a propriedade 'name' enviada no corpo da requisição
    const { nome } = req.body;

    //Adiciona o novo curso ao array de cursos
    livros.push(nome);

    //Retorna a lista atualizada de cursos
    return res.json(livros);
});


//Atualizar um livro
server.put('/livro-novo/:id', (req, res) => {

    //Busca os dados vindos da URL (rota)
    const { id } = req.params;

    //Desestrutura a propriedade enviada no corpo da requisição
    const { nome } = req.body;

    // Ele acessa o id do array 'livros' e depois insere o valor digitado
    livros[id] = nome;

    return res.json(livros);
});

//Remover um livro
server.delete("/livro/:index", (req, res) => {

    //Busca os dados vindos da URL (rota)
    const { index } = req.params;

    //a .splice() remove a posição que o usuário digitar na URL e apenas 1
    livros.splice(index, 1);

    //retorna a lista com a exclusão
    return res.json(livros);
});


//Faz o servidor escutar a porta 3004 pro código
server.listen(3004, () => {
    console.log("Rodando na porta 3004")
});