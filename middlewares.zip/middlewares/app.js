//Importa o framework express
const express = require('express');
const connection = require('./db');
const server = express();

//Middleware que permite o servidor entender requisições com JSON no corpo (req.body)
server.use(express.json());

const cursos = ['Node JS', 'JavaScript', 'React Native'];



// Middleware Global
server.use((req, res, next) => {
    console.log("Requisição chamada.")

    return next();
});


// Middleware Local
function cursoExiste(req, res, next) {
};

function idCursoExiste (req, res, next) {
    const curso = cursos[req.params.id];
    if (!curso) {
        return res.status(400).json({ erro: "Curso não encontrado" });
    }
    return next();
};

//===================================
//Método HTTP: GET
//LISTAR TODOS OS CURSOS
//localhost:3023/cursos
server.get('/cursos', (req, res) => {
    const sql = 'SELECT * FROM cursos';

    connection.query(sql, (erro, resultados) => {
        if (erro){
            return res.status(500).json({ erro: erro.message });
        }
        return res.json(resultados);
    })
});

//Método HTTP: GET
//LISTAR UM UNICO CURSO
//localhost:3023/cursos/2
server.get('/cursos/:id', (req, res) => {

    const { id } = req.params;

    const sql = 'SELECT * FROM cursos WHERE id_curso = ?';

    connection.query(sql, [id], (erro, resultados) => {
        if (erro){
            return res.status(500).json({ erro: erro.message });
        }
        return res.json(resultados[0])
    })
});

//Método HTTP: POST
//CRIAR UM NOVO CURSO
//localhost:3023/cursos
//{ "name": "Curso de Python" }
server.post('/cursos', cursoExiste, (req, res)=> {

    // Desestrutura a propriedade "name" enviada no corpo da requisição
    const { nome } = req.body;

    // Adiciona o novo curso ao array de cursos
    cursos.push(nome);

    // Retorna a lista atualizada de cursos
    return res.json(cursos);    
});

//Método HTTP: PUT
//ATUALIZAR UM CURSO
//localhost:3023/cursos/0
server.put('/cursos/:id', idCursoExiste, (req, res) => {

    // Obtém o índice do curso a ser atualizado pela URL
    const id = req.params.id;

    // Obtém o novo nome do curso enviado no corpo da requisição
    const nome = req.body.nome;

    // Atualiza o curso no índice informado
    cursos[id] = nome;

    // Retorna a lista de cursos atualizada
    return res.json(cursos);

});

//Método HTTP: DELETE
//DELETAR UM CURSO
//localhost:3023/cursos/1
server.delete('/cursos/:id', idCursoExiste, (req, res) => {

    // Obtém o índice do curso a ser removido
    const id = req.params.id;

    // Remove 1 elemento do array a partir do índice informado
    cursos.splice(id, 1);

    // Retorna a lista de cursos após a exclusão
    return res.json(cursos);
});



//O metodo listen() faz o servidor começar a escutar
// requisiçoes em uma determinada porta.
server.listen(3023 , () => {
    console.log("Servidor rodando na porta 3023");
});