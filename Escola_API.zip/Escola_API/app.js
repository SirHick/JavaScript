const express = require('express');

const server = express();

// ================================
// Entendendo query e route params:
// ================================

//Query params = ?nome=Nodejs
//Route Params = /curso/2
//Request Body = { "name": "Nodejs", tipo: "Backend" }

const cursos = ['Nodejs', 'JavaScript', 'HTML', 'Python'];

//Rota 1: Query params
server.get('/curso', (req, res) => {
    
    //Query params

    const nome = req.query.nome
    return res.json({ curso: `Aprendendo ${nome}` });

});

//Rota 2: Route params
server.get('/curso/:id', (req, res) => {

    //Route params

    const id = req.params.id
    return res.json(cursos[id]);

});

server.get('/cursos', (req, res) => {
    return res.json(cursos)
});


//Faz o código abaixo ser interpretado como JSON
server.use(express.json());

server.post('/cursos', (req, res) => {
    
    //Desestrutura a propriedade 'name' enviada no corpo da requisição
    const { nome } = req.body;
    
    //Adiciona o novo curso ao array de cursos
    cursos.push(nome);

    //Retorna a lista atualizada de cursos
    return res.json(cursos);
});


server.put('/cursos/:id', (req, res) => {

    const { id } = req.params;
    const { nome } = req.body;

    cursos[id] = nome;

    return res.json(cursos);
});

server.listen(3003, () => {
    console.log('Servidor rodando na porta 3003');
});