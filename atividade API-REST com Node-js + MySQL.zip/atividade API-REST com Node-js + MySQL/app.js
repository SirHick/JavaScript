//Importa o framework express
const express = require('express');
const connection = require('./db');
const server = express();

//Middleware que permite o servidor entender requisições com JSON no corpo (req.body)
server.use(express.json());

//===================================
//Método HTTP: GET
//LISTAR TODOS OS CURSOS
server.get('/destinos', (req, res) => {
    const sql = 'SELECT * FROM destinos';

    connection.query(sql, (erro, resultados) => {
        if (erro){
            return res.status(500).json({ erro: erro.message });
        }
        return res.json(resultados);
    })
});

//Método HTTP: GET
//LISTAR UM UNICO CURSO
//localhost:3023/cursos/2
server.get('/cursos/:id', (req, res) => {

    const { id } = req.params;

    const sql = 'SELECT * FROM cursos WHERE id = ?';

    connection.query(sql, [id], (erro, resultados) => {
        if (erro){
            return res.status(500).json({ erro: erro.message });
        }
        return res.json(resultados[0])
    })
});

//Método HTTP: POST
//CRIAR UM NOVO CURSO
//localhost:3023/cursos
//{ "name": "Curso de Python" }
server.post('/cursos', (req, res) => {

    const { nome } = req.body;
    const sql = 'INSERT INTO cursos (nome) VALUES (?)';

    connection.query(sql, [nome], (erro, resultados) => {
        // 1. Se houver erro, responde o cliente e encerra a execução aqui
        if (erro) {
            return res.status(500).json({ erro: erro.message });
        }

        // 2. O sucesso DEVE ficar aqui dentro, onde "resultados" existe
        // e garante que só vai rodar DEPOIS que o banco responder.
        return res.json({
            mensagem: 'Curso cadastrado com sucesso',
            id: resultados.insertId,
            nome: nome
        });
    });

});

//Método HTTP: PUT
//ATUALIZAR UM CURSO
//localhost:3023/cursos/0
server.put('/cursos/:id', (req, res) => {

    const { id } = req.params;
    const { nome } = req.body;

    const sql = 'UPDATE cursos SET nome = ? WHERE id = ?';
    connection.query(sql, [nome, id], (erro, resultados) => {

        if(erro){
            return res.status(500).json({ erro: erro.message});
        }

        return res.json({
            mensagem: 'Curso atualizado com sucesso',
            nome: nome
        })
    })
});

//Método HTTP: DELETE
//DELETAR UM CURSO
//localhost:3023/cursos/1
server.delete('/cursos/:id', (req, res) => {

    // Obtém o índice do curso a ser removido
    const { id } = req.params;
    const sql = 'DELETE FROM cursos WHERE id = ?';

    connection.query(sql, [id], (erro) => {
        if(erro) {
            return res.status(500).json({ erro: erro.message});
        }
        return res.json({
            mensagem: 'Curso removido com sucesso.',
            id: id
        })
    })
});



//O metodo listen() faz o servidor começar a escutar
// requisiçoes em uma determinada porta.
server.listen(3005 , () => {
    console.log("Servidor rodando na porta 3005");
});